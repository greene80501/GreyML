"""GreyML utility helpers.
IO and metrics glue around the tensor API.
"""

